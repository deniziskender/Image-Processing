/* Deniz Iskender S000704 Department of Computer Science */
#include "opencv2/opencv.hpp"

using namespace cv;
using namespace std;

double calculatePixelValueOfImage(int halfOfFilter, Mat image, int imageX, int imageY, Mat filter){

	double ImageValue = 0.0;
	double pixelValue = 0.0;

	for (int filterX = -halfOfFilter; filterX <= halfOfFilter; filterX++){
		for (int filterY = -halfOfFilter; filterY <= halfOfFilter; filterY++){
			pixelValue = image.at<uchar>(imageX + filterX, imageY + filterY) * 
						 filter.at<float>(filterX + halfOfFilter, filterY + halfOfFilter);
			ImageValue += pixelValue;
		}
	}
	return ImageValue;
}

cv::Mat applyFilter(cv::Mat image, cv::Mat filter){
	
	//size of each image should be less than taken image.
	//This depends size of filter
	
	//Even if size of filter is even, it works.
	int halfOfFilter = int (filter.rows / 2);
	int sizeOfFilter = 2 * halfOfFilter;

	int rowsOfImage = image.rows;
	int colsOfImage = image.cols;

	cv::Mat filteredImage = Mat::zeros(rowsOfImage - sizeOfFilter, colsOfImage - sizeOfFilter, CV_8UC1);

	//Go over the given image
	for (int imageX = halfOfFilter; imageX < rowsOfImage - halfOfFilter; imageX++){
		for (int imageY = halfOfFilter; imageY < colsOfImage - halfOfFilter; imageY++){
			//apply the filter to the given image
			//write value to new image
			uchar pixelValue = (uchar)(calculatePixelValueOfImage(halfOfFilter, image, imageX, imageY, filter));
			filteredImage.at<uchar>(imageX - halfOfFilter, imageY - halfOfFilter) = pixelValue;
		}
	}
	return filteredImage;
}

int main(int argc, char** argv) {
	
	//check number of arguments
	if (argc != 4){
		std::cout << "Error : Number of elements are false!"; 
		return -1;
	}

	//take the inputs
	char * takenVideo = argv[1];
	char * readCsvFile = argv[2];
	char * takenVideoName = argv[3];

	//Take video and check whether it is opened correctly or not
	cv::VideoCapture inputVideo(takenVideo);
	if (!inputVideo.isOpened()) {
		std::cout << "Input video could not be opened correctly!" << std::endl;
		return -1;
	}

	//read the csv file(filter)
	CvMLData CSVfile;
	CSVfile.read_csv(readCsvFile);
	const CvMat* tmp = CSVfile.get_values();
	Mat filter(tmp, true);
	
	//check whether csv file(filter) is square or not. 
	if (filter.rows != filter.cols){
		std::cout << "Csv file is not in the wanted format!";
		return -1;
	}
	//create parameters for filtered image
	int half = filter.rows / 2;
	int inputVideo_fps = inputVideo.get(CV_CAP_PROP_FPS);
	int inputVideo_width = inputVideo.get(CV_CAP_PROP_FRAME_WIDTH);
	int inputVideo_height = inputVideo.get(CV_CAP_PROP_FRAME_HEIGHT);

	//create filtered video
	//size should be less compared to taken  video
	//This depends size of filter
	cv::VideoWriter filteredVideo(takenVideoName, -1, inputVideo_fps,
		cv::Size(inputVideo_width - (2 * half), inputVideo_height - (2 * half)));
	
	//check whether filtered video is opened correctly or not
	if (!filteredVideo.isOpened()){
		std::cout << "Filtered video could not be opened correctly!" << std::endl;
		return -1;
	}

	//take the frames and apply them filtes then write them to output file. 
	while (true){

		//read the frames from viode
		Mat frame;
		bool bSuccess = inputVideo.read(frame); // read a new frame from video

		//if not success, break loop
		if (!bSuccess) {
			break;
		}

		//converted taken RGB pixel to gray so that I can work on just one channel
		cvtColor(frame, frame, COLOR_BGR2GRAY);

		//apply fiter to every image of video
		//take these images and write them to filtered video
		Mat finalPixel = applyFilter(frame, filter);
		filteredVideo.write(finalPixel);

		cvWaitKey(10);
	}
	return 0;
}