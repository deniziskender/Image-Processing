/* Deniz Iskender S000704 Department of Computer Science */
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

double calculatePixelValueOfImage(int halfOfFilter, Mat image, int imageX, int imageY, Mat filter){

	double ImageValue = 0.0;
	double pixelValue = 0.0;

	for (int filterX = -halfOfFilter; filterX <= halfOfFilter; filterX++){
		for (int filterY = -halfOfFilter; filterY <= halfOfFilter; filterY++){
			pixelValue = image.at<uchar>(imageX + filterX, imageY + filterY) *
				filter.at<float>(filterX + halfOfFilter, filterY + halfOfFilter);
			ImageValue += pixelValue;
		}
	}
	return ImageValue;
}

cv::Mat applyFilter(cv::Mat image, cv::Mat filter){

	//size of each image should be less than taken image.
	//This depends size of filter

	//Even if size of filter is even, it works.
	int halfOfFilter = int(filter.rows / 2);
	int sizeOfFilter = 2 * halfOfFilter;

	int rowsOfImage = image.rows;
	int colsOfImage = image.cols;

	cv::Mat filteredImage = Mat::zeros(rowsOfImage - sizeOfFilter, colsOfImage - sizeOfFilter, CV_8UC1);

	//Go every pixel of the given image
	for (int imageX = halfOfFilter; imageX < rowsOfImage - halfOfFilter; imageX++){
		for (int imageY = halfOfFilter; imageY < colsOfImage - halfOfFilter; imageY++){
			//apply the filter to the given image
			//write value to new image
			uchar pixelValue = (uchar)(calculatePixelValueOfImage(halfOfFilter, image, imageX, imageY, filter));
			filteredImage.at<uchar>(imageX - halfOfFilter, imageY - halfOfFilter) = pixelValue;
		}
	}
	return filteredImage;
}



int main(int argc, char **argv) {

	if (argc != 4) {
		std::cout << "Error : no of inputs must be three \n"; return -1;
	}

	//take the inputs
	char * takenImage = argv[1];
	char * readCsvFile = argv[2];
	char * takenImageName = argv[3];

	Mat Image = imread(takenImage, CV_LOAD_IMAGE_GRAYSCALE);

	if (Image.empty()) {
		std::cout << "!!! Failed imread(): image not found" << std::endl;
		// don't let the execution continue, else imshow() will crash.
	}
	CvMLData mlData;

	//read the csv file(filter)
	CvMLData CSVfile;
	CSVfile.read_csv(readCsvFile);
	const CvMat* tmp = CSVfile.get_values();
	Mat filter(tmp, true);

	//check whether csv file(filter) is square or not. 
	if (filter.rows != filter.cols){
		std::cout << "Csv file is not in the wanted format!";
		return -1;
	}

	Mat filteredImage = applyFilter(Image, filter);

	cv::imwrite(takenImageName, filteredImage);

	//namedWindow("Display window", CV_WINDOW_AUTOSIZE);// Create a window for display.
	//imshow("Display window", filteredImage);

}