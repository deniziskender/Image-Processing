/* Deniz Iskender S000704 Department of Computer Science */

//I do bonus part reading image gray scale.
//I am reading colored hands as a gray scale 
//so that I don�t have to deal with their colors.

#include <opencv2/opencv.hpp>
#include <dirent.h>
#include "opencv2/imgproc/imgproc.hpp"
using namespace cv;
using namespace std;

int convertDegreeToClock(int parameter){
	if (parameter < 0 && -89 <= parameter){
		parameter = abs(parameter) + 270;
	}
	else if (parameter <= -90 && -180 <= parameter){
		parameter = abs(parameter) - 90;
	}
	else if (parameter <= 90 && 0 <= parameter){
		parameter = 270 - abs(parameter);
	}
	else if (parameter <= 180 && 90 < parameter){
		parameter = 270 - abs(parameter);
	}
	return parameter;
}
double startDecideAndEndPointsAndCalculateDegree(Mat src, Vec4i hand){
	
	int centerX = src.rows / 2;
	int centerY = src.cols / 2;

	int Possiblestart = sqrt(((hand[0] - centerX) * (hand[0] - centerX)) +
		((hand[1] - centerY) * (hand[1] - centerY)));
	int Possibleend = sqrt(((hand[2] - centerX) * (hand[2] - centerX)) +
		((hand[3] - centerY) * (hand[3] - centerY)));

	int y, x;

	double degree;

	if (Possiblestart > Possibleend){
		//hourHand[0] and hourHand[1] end points
		//hourHand[2] and hourHand[3] start points
		y = hand[3] - hand[1];
		x = hand[2] - hand[0];

		degree = atan2(-y, x) * 180 / CV_PI;
	}
	else{
		//l[0] and l[1] start points
		//l[2] and l[3] end points

		y = hand[1] - hand[3];
		x = hand[0] - hand[2];

		degree = atan2(-y, x) * 180 / CV_PI;
	}
	return degree;

}
void createTimeDependingOnDegree(String name, double degreeOfHourHand, double degreeOfMinuteHand){

	int whereHourHandLocates = (int)(degreeOfHourHand / 30);
	double whereMinuteHandLocates = (degreeOfMinuteHand / 30);

	int a = (int)whereHourHandLocates / 10;
	int b = (int)5 * whereMinuteHandLocates / 10;
	 
	if (a == 0 && b == 0){
		cout << name << "=" << "0" << whereHourHandLocates << ":" << "0" << int(whereMinuteHandLocates * 5) << endl;
	}
	else if (!a == 0 && b == 0){
		cout << name << "=" << whereHourHandLocates << ":" << "0" << int(whereMinuteHandLocates * 5) << endl;
	}
	else if (a == 0 && !b == 0){
		cout << name << "=" << "0" << whereHourHandLocates << ":" << int(whereMinuteHandLocates * 5) << endl;
	}
	else if (!a == 0 && !b == 0){
		cout << name << "=" << whereHourHandLocates << ":" << int(whereMinuteHandLocates * 5) << endl;
	}
}

int main(int argc) {

	//be careful, only PRJ4-S000704.exe is accepted as an argument.
	if (argc != 1) {
		std::cout << "Error : number of inputs should be one! \n";
		return -1;
	}
	//enter to dataset
	vector<string> namesOfImages;

	DIR *dir;
	struct dirent *ent;

	if ((dir = opendir("DATASET")) != NULL) {
		while ((ent = readdir(dir)) != NULL) {
			if (string(ent->d_name) == "." || string(ent->d_name) == ".."){

			}
			else{
				namesOfImages.push_back(string(ent->d_name));
			}
		}
		closedir(dir);
	}


	//take the images
	for (int i = 0; i < namesOfImages.size(); i++){
		String name = namesOfImages.at(i);
		Mat src = imread("DATASET/" + name, CV_LOAD_IMAGE_GRAYSCALE);

		if (src.empty()) {
			std::cout << "!!! Failed imread(): image not found" << std::endl;
		}
		//find circles and get rid of them
		vector<Vec3f> circles;
		HoughCircles(src, circles, CV_HOUGH_GRADIENT, 1, src.rows / 8, 100, 100, 0, 0);
		for (size_t i = 0; i < circles.size(); i++) {
			Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
			int radius = cvRound(circles[i][2]);
			circle(src, center, 3, Scalar(0, 0, 0), -1, 8, 0);
			circle(src, center, 3, Scalar(0, 0, 0), 0, 8, 0);
			circle(src, center, 3, Scalar(0, 0, 0), 2, 8, 0);
			circle(src, center, radius, Scalar(0, 0, 0), 3, 8, 0);
		}
		//otsu threshold 
		threshold(src, src, 50, 255, CV_THRESH_BINARY | CV_THRESH_OTSU);

		int erosion_size = 1;
		Mat element = getStructuringElement(cv::MORPH_CROSS,
			Size(2 * erosion_size + 1, 2 * erosion_size + 1), Point(erosion_size, erosion_size));

		// Apply erosion the image
		erode(src, src, element);

		//Apply a Gaussian blur to reduce noise :
		GaussianBlur(src, src, Size(5, 5), 3, 3);
		medianBlur(src, src, 3);

		//Detect the edges of the image by using a Canny detector
		Mat dst, cdst;
		Canny(src, dst, 100, 150, 3);
		cvtColor(dst, cdst, CV_GRAY2BGR);

		//threshold: The minimum number of intersections to �detect� a line
		//minLinLength : The minimum number of points that can form a line.Lines with less than this number of points are disregarded.
		//maxLineGap : The maximum gap between two points to be considered in the same line.
		vector<Vec4i> lines;
		HoughLinesP(dst, lines, 1, CV_PI / 90, 40, 30, 5);

		for (size_t i = 0; i < lines.size(); i++) {
			Vec4i l = lines[i];
			line(cdst, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0, 0, 255), 3, CV_AA);
		}
		if (lines.size() == 0){
			cout << name << "=" << "00:00" << endl;
		}
		else{
			//GET LINES CLOSER TO CENTER
			vector<Vec4i> linesInCenter;

			for (int i = 0; i < lines.size(); i++){
				Vec4i l = lines[i];
				if ((abs(l[0] - src.rows / 2) <= src.rows / 8) && (abs(l[1] - src.cols / 2) <= src.rows / 8)){
					linesInCenter.push_back(l);
				}
				else if ((abs(l[2] - src.rows / 2) <= src.rows / 8) && (abs(l[3] - src.cols / 2) <= src.rows / 8)){
					linesInCenter.push_back(l);
				}
			}

			vector<Vec4i> allNeededLines;
			allNeededLines.push_back(linesInCenter[0]);

			if (linesInCenter.size() == 0){
				cout << name << "=" << "00:00" << endl;
			}
			else{
				
				//GET RID OF USELESS LINES
				for (int i = 1; i < linesInCenter.size(); i++) {
					Vec4i l = linesInCenter[i];
					bool value = true;
					for (int j = 0; j <= i; j++) {
						Vec4i k = linesInCenter[j];
						if ((abs(k[2] - l[2]) <= src.rows/10) && (abs(k[3] - l[3]) <= src.cols/10)){
							//itself
							if (((k[2] == l[2]) || (l[2] == k[2] + src.rows / 10)) && ((k[3] == l[3]) || (l[3] == k[3] + src.cols / 10))){
							}
							else{
								//similar
								value = false;
								break;
							}
						}
					}
					if (value == true){
						allNeededLines.push_back(linesInCenter[i]);
					}
				}
				//If there is no read line
				if (allNeededLines.size() == 0){
					break;
				}

				//THERE IS ONLY ONE HAND WHICH MEANS
				//ALL HANDS ARE AT SAME LOCATIONS 
				else if (allNeededLines.size() == 1){
					Vec4i hand = allNeededLines[0];

					double degreeOfHourHand = startDecideAndEndPointsAndCalculateDegree(src, hand);
					double degreeOfMinuteHand = startDecideAndEndPointsAndCalculateDegree(src, hand);

					degreeOfHourHand = convertDegreeToClock(degreeOfHourHand);
					degreeOfMinuteHand = convertDegreeToClock(degreeOfMinuteHand);

					createTimeDependingOnDegree(name, degreeOfHourHand, degreeOfMinuteHand);
				}

				//THERE ARE ONLY HOUR AND MINUTE HANDS
				else if (allNeededLines.size() == 2){
				
					Vec4i l = allNeededLines[0];
					Vec4i k = allNeededLines[1];

					double sizeOfZeroth = sqrt(((l[2] - l[0]) * (l[2] - l[0])) + ((l[3] - l[1]) * (l[3] - l[1])));
					double sizeOfFirst = sqrt(((k[2] - k[0]) * (k[2] - k[0])) + ((k[3] - k[1]) * (k[3] - k[1])));

					Vec4i hourHand;
					Vec4i minuteHand;
					if (sizeOfZeroth < sizeOfFirst){
						hourHand = allNeededLines[0];
						minuteHand = allNeededLines[1];
					}
					else{
						hourHand = allNeededLines[1];
						minuteHand = allNeededLines[0];
					}

					double degreeOfHourHand = startDecideAndEndPointsAndCalculateDegree(src, hourHand);
					double degreeOfMinuteHand = startDecideAndEndPointsAndCalculateDegree(src, minuteHand);

					degreeOfHourHand = convertDegreeToClock(degreeOfHourHand);
					degreeOfMinuteHand = convertDegreeToClock(degreeOfMinuteHand);

					createTimeDependingOnDegree(name, degreeOfHourHand, degreeOfMinuteHand);

				}

				//THERE ARE HOUR, MINUTE AND SECOND HANDS
				else {
					Vec4i k = allNeededLines[0];
					Vec4i l = allNeededLines[1];
					Vec4i m = allNeededLines[2];

					int sizeOfL = sqrt(((l[2] - l[0]) * (l[2] - l[0])) + ((l[3] - l[1]) * (l[3] - l[1])));
					int sizeOfK = sqrt(((k[2] - k[0]) * (k[2] - k[0])) + ((k[3] - k[1]) * (k[3] - k[1])));
					int sizeOfM = sqrt(((m[2] - m[0]) * (m[2] - m[0])) + ((m[3] - m[1]) * (m[3] - m[1])));

					Vec4i hourHand;
					Vec4i minuteHand;
					Vec4i secondHand;

					//According to their size, I find hourhand, minutehand and secondhand
					if (sizeOfL < sizeOfK && sizeOfK < sizeOfM){
						hourHand = l; minuteHand = k; secondHand = m;
					}
					else if (sizeOfK < sizeOfL && sizeOfL < sizeOfM){
						hourHand = k; minuteHand = l; secondHand = m;
					}
					else if (sizeOfL < sizeOfM && sizeOfM < sizeOfK){
						hourHand = l; minuteHand = m; secondHand = k;
					}
					else if (sizeOfM < sizeOfL && sizeOfL < sizeOfK){
						hourHand = m; minuteHand = l; secondHand = k;
					}
					else if (sizeOfK < sizeOfM && sizeOfM < sizeOfL){
						hourHand = k; minuteHand = m; secondHand = l;
					}
					else if (sizeOfM < sizeOfK && sizeOfK < sizeOfL){
						hourHand = m; minuteHand = k; secondHand = l;
					}
					double degreeOfHourHand = startDecideAndEndPointsAndCalculateDegree(src, hourHand);
					double degreeOfMinuteHand = startDecideAndEndPointsAndCalculateDegree(src, minuteHand);

					degreeOfHourHand = convertDegreeToClock(degreeOfHourHand);
					degreeOfMinuteHand = convertDegreeToClock(degreeOfMinuteHand);

					int whereHourHandLocates = (int)(degreeOfHourHand / 30);
					double whereMinuteHandLocates = (degreeOfMinuteHand / 30);

					createTimeDependingOnDegree(name, degreeOfHourHand, degreeOfMinuteHand);

				}
				waitKey(0);
			}
		}
	}
}