/* Deniz Iskender S000704 Department of Computer Science */
#include <string>
#include <dirent.h>
#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

cv::Mat getHistogram(cv::Mat image, int quantum){

	int numberOfBins = 256 / quantum;
	
	//GET THE PIXELS OF IMAGE
	cv::Mat histogram = Mat::zeros(1, numberOfBins * image.channels(), CV_32FC1);
	
	for (int imageX = 0; imageX < image.rows; imageX++){
		for (int imageY = 0; imageY < image.cols; imageY++){
			Vec3b pixel = image.at<Vec3b>(imageX, imageY);
			//GET THE CHANNELS OF PIXEL
			for (int i = 0; i < pixel.channels; i++){
				int color = pixel[i];
				//CREATE HISTOGRAM DEPENDING ON RGB VALUE OF PIXEL AND QUANTUM
				histogram.at<float>(0, color / quantum * (i + 1)) += 1;
			}
		}
	}
	//NORMALIZATION
	float sum = 0;
	for (int imageX = 0; imageX < histogram.cols; imageX++){
		sum += histogram.at<float>(0, imageX);
	}
	for (int imageX = 0; imageX < histogram.cols; imageX++){
		histogram.at<float>(0, imageX) = (float) histogram.at<float>(0, imageX) / sum;
	}
	return histogram;
}

cv::Mat getHistogramTwoByTwo(cv::Mat image, int quantum){

	int numberOfBins = 256 / quantum;

	cv::Mat histogram = Mat::zeros(1, 4 * numberOfBins * image.channels(), CV_32FC1);

	//I will divide the image into 4 category
	//Depending on these categories, I will update histogram which has also 4 parts.
	int whichPartOfImage = 1;
	
	//GET THE PIXELS OF IMAGE
	for (int imageX = 0; imageX < image.rows; imageX++){
		for (int imageY = 0; imageY < image.cols; imageY++){
			Vec3b pixel = image.at<Vec3b>(imageX, imageY);
			//Find the part of given image and change the 
			if (imageX < image.rows && imageX < image.cols){
				whichPartOfImage = 1;
			}
			else if (imageX < image.rows  && imageY > image.cols){
				whichPartOfImage = 2;
			}
			else if (imageX > image.rows && imageX < image.cols){
				whichPartOfImage = 3;
			}
			else {
				whichPartOfImage = 4;
			}

			//GET THE CHANNELS OF PIXEL
			for (int i = 0; i < pixel.channels; i++){
				int color = pixel[i];
				histogram.at<float>(0, whichPartOfImage *(i + 1) * color / quantum) += 1;
			}
		}
	}
	//NORMALIZATION
	float sum = 0;
	for (int imageX = 0; imageX < histogram.cols; imageX++){
		sum += histogram.at<float>(0, imageX);
	}
	for (int imageX = 0; imageX < histogram.cols; imageX++){
		histogram.at<float>(0, imageX) = (float)histogram.at<float>(0, imageX) / sum;
	}

	return histogram;
}

float compareHistograms(Mat testMat, Mat trainingMat){
	
	float total = 0.0f;
	
	for (int k = 0; k < testMat.cols; k++){
		total += min(testMat.at<float>(0, k), trainingMat.at<float>(0, k));
	}

	float hisint = 1.0f - total;

	return hisint;
}
float compareHistogramsWithChiSqure(Mat testMat, Mat trainingMat){

	float total = 0;
	float dividend = 0;
	float divider = 0;

	for (int k = 0; k < testMat.cols; k++){
		dividend = (testMat.at<float>(0, k) - trainingMat.at<float>(0, k)) * (testMat.at<float>(0, k) - trainingMat.at<float>(0, k));
		divider = testMat.at<float>(0, k) + trainingMat.at<float>(0, k);
		//Be careful about the divider because it can be 0
		//then something / 0 division will happen.
		//Therefore, I got rid of it. 
		if (divider == 0){
			continue;
		}
		total += (float) dividend / divider;
	}
	total /= 2;

	float hisint = 1 - total;

	return hisint;
}

void createResults(map<String, Vector<Mat>> AllImages){

	Vector<Mat> trainingHistograms;
	map<String, Vector<Mat>> TrainingImagesAndTheirHistograms;

	Vector<Mat> testHistograms;
	map<String, Vector<Mat>> TestImagesAndTheirHistograms;

	int numberOfTestImages = 0;

	int quantum = 64;
	//ENTER TO ALL DIRECTORIES
	map<String, Vector<Mat>>::iterator outer;
	for (outer = AllImages.begin(); outer != AllImages.end(); ++outer) {
		//TRAVERSE ALL VECTORS IN TAKEN DIRECTORY
		Vector<Mat>::iterator inner = outer->second.begin();
		for (inner; inner != outer->second.end(); ++inner) {
			//TAKE TRAINING AND TEST HISTOGRAMS USING COMPARE HISTOGRAMS AND COMPARE HISTOGRAMS CHI SQUARE
			if (numberOfTestImages < outer->second.size() / 2) {
				trainingHistograms.push_back(getHistogram(*inner, quantum));
			}
			else{
				testHistograms.push_back(getHistogram(*inner, quantum));
			}
			numberOfTestImages++;
		}
		numberOfTestImages = 0;
		TrainingImagesAndTheirHistograms[outer->first] = trainingHistograms;
		TestImagesAndTheirHistograms[outer->first] = testHistograms;

		trainingHistograms.clear();
		testHistograms.clear();
	}
	int success = 0;
	int failure = 0;

	//ENTER TO EACH TEST DIRECTORY
	for (auto testOuter = TestImagesAndTheirHistograms.begin(); testOuter != TestImagesAndTheirHistograms.end(); ++testOuter) {
		double sc = 0;
		double fai = 0;
		//GET EACH TEST HISTOGRAM.
		for (auto testInner = testOuter->second.begin(); testInner != testOuter->second.end(); ++testInner) {
			double prcntge = 0;
			Mat testMat = *testInner;
			string categoryName = " ";
			float minimum = FLT_MAX;
			//ENTER TO EACH TRAINING DIRECTORY
			for (auto trainingOuter = TrainingImagesAndTheirHistograms.begin(); trainingOuter != TrainingImagesAndTheirHistograms.end(); ++trainingOuter) {
				//GET EACH TEST HISTOGRAM
				for (auto trainingInner = trainingOuter->second.begin(); trainingInner != trainingOuter->second.end(); ++trainingInner) {
				
					Mat trainingMat = *trainingInner;
					//COMPARE HISTOGRAMS
					//float histint = compareHistograms(testMat, trainingMat);
					float histint = compareHistogramsWithChiSqure(testMat, trainingMat);
					
					if (histint < minimum){
						minimum = histint;
						categoryName = trainingOuter->first;						
					}
				}
			}
			//FOR ONE TEST IMAGE; ALL DIRECTORIES TRAVELLED
			if (categoryName.compare(testOuter->first) == 0){
				success += 1;
				sc += 1;
			}
			else{
				failure += 1;
				fai += 1;
			}
		}
		cout << "Directory: " << testOuter->first << "  Percantage: " << (double) sc / (sc + fai) * 100 << endl;
	}
	cout << "All Results" << endl;
	cout << "The value of general success is: " << success << endl;
	cout << "The value of general failure is: " << failure << endl;
	cout << "General Percentage: " << (double)success / (success + failure) * 100;

}

int main() {

	//TAKE DIRECTORY NAMES
	vector<string> namesOfDirectories;

	DIR *dir;
	struct dirent *ent;

	if ((dir = opendir("C://Users//student//Documents//Visual Studio 2013//Projects//PRJ2-3-S000704//Debug//DATASET")) != NULL) {
		while ((ent = readdir(dir)) != NULL) {
			if (string(ent->d_name) == "." || string(ent->d_name) == ".."){

			}
			else{
				namesOfDirectories.push_back(string(ent->d_name));
		}
		}
		closedir(dir);
	}
	else {
		perror("");
		return EXIT_FAILURE;
	}
	
	//TAKE ALL IMAGES IN TAKEN DIRECTORIES
	map<String, Vector<Mat>> AllImages;

	for (int i = 0; i < namesOfDirectories.size(); i++){
			string dirName = "C://Users//student//Documents//Visual Studio 2013//Projects//PRJ2-3-S000704//Debug//DATASET//"
				+ namesOfDirectories.at(i);

			DIR *dir;
			dir = opendir(dirName.c_str());

			string imgName;
			if (dir != NULL) {
				Vector <Mat> allMatsInOneDirectory;

				while ((ent = readdir(dir)) != NULL) {

					imgName = string(ent->d_name);

					if (imgName == "." || imgName == ".."){

					}
					else{
						Mat img = imread(dirName + "//" + imgName, 1);
						allMatsInOneDirectory.push_back(img);
					}
				}
				AllImages[namesOfDirectories[i]] = allMatsInOneDirectory;
				closedir(dir);
			}
			else {
				cout << "not present" << endl;
			}
	}
	
	createResults(AllImages);

	return 0;
}