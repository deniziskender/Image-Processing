/* Deniz Iskender S000704 Department of Computer Science */
#include <string>
#include <dirent.h>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>

using namespace std;
using namespace cv;

Mat getHistogramFourByFour(Mat image, int quantum){

	int numberOfBins = 256 / quantum;
	//CREATE HISTOGRAM WHICH EXIST FROM 0's
	Mat histogram = Mat::zeros(1, 16 * numberOfBins * image.channels(), CV_32FC1);
	

	//I will divide the image into 16 category
	//Depending on these categories,
	int whichPartOfImage = 0;

	//GET THE PIXELS OF IMAGE
	for (int imageX = 0; imageX < image.rows; imageX++){
		for (int imageY = 0; imageY < image.cols; imageY++){
			Vec3b pixel = image.at<Vec3b>(imageX, imageY);

			//Find the part of given image and change the 
			if ((image.cols * 3) / 4 <= imageY && imageY < image.cols && (image.rows * 3) / 4 <= imageX && imageX < image.rows){
				whichPartOfImage = 16;
			}
			else if (image.cols / 2 <= imageY && imageY < (image.cols * 3) / 4 && (image.rows * 3) / 4 <= imageX && imageX < image.rows){
				whichPartOfImage = 15;
			}
			else if (image.cols / 4 <= imageY && imageY < image.cols / 2 && (image.rows * 3) / 4 <= imageX && imageX < image.rows){
				whichPartOfImage = 14;
			}
			else if (imageY < image.cols / 4 && (image.rows * 3) / 4 <= imageX && imageX < image.rows){
				whichPartOfImage = 13;
			}
			else if ((image.cols * 3) / 4 <= imageY && imageY < image.cols && image.rows / 2 <= imageX && imageX < (image.rows * 3) / 4){
				whichPartOfImage = 12;
			}
			else if (image.cols / 2 <= imageY && imageY < (image.cols * 3) / 4 && image.rows / 2 <= imageX && imageX < (image.rows * 3) / 4){
				whichPartOfImage = 11;
			}
			else if (image.cols / 4 <= imageY && imageY < image.cols / 2 && image.rows / 2 <= imageX && imageX < (image.rows * 3) / 4){
				whichPartOfImage = 10;
			}
			else if (imageY < image.cols / 4 && image.rows / 2 <= imageX && imageX < (image.rows * 3) / 4){
				whichPartOfImage = 9;
			}
			else if ((image.cols * 3) / 4 <= imageY && imageY < image.cols && image.rows / 4 <= imageX && imageX < image.rows / 2){
				whichPartOfImage = 8;
			}
			else if (image.cols / 2 <= imageY && imageY < (image.cols * 3) / 4 && image.rows / 4 <= imageX && imageX < image.rows / 2){
				whichPartOfImage = 7;
			}
			else if (image.cols / 4 <= imageY && imageY < image.cols / 2 && image.rows / 4 <= imageX && imageX < image.rows / 2){
				whichPartOfImage = 6;
			}
			else if (imageY < image.cols / 4 && image.rows / 4 <= imageX && imageX < image.rows / 2){
				whichPartOfImage = 5;
			}
			else if ((image.cols * 3) / 4 <= imageY && imageY < image.cols && imageX < image.rows / 4){
				whichPartOfImage = 4;
			}
			else if (image.cols / 2 <= imageY && imageY < (image.cols * 3) / 4 && imageX < image.rows / 4){
				whichPartOfImage = 3;
			}
			else if (image.cols / 4 <= imageY && imageY < image.cols / 2 && imageX < image.rows / 4){
				whichPartOfImage = 2;
			}
			else if (imageY < image.cols / 4 && imageX < image.rows / 4){
				whichPartOfImage = 1;
			}
			
			//GET THE CHANNELS OF PIXEL
			for (int i = 0; i < pixel.channels; i++){
				int color = pixel[i];
				histogram.at<float>(0, whichPartOfImage * (i + 1) * (color / quantum)) += 1;
			}
		}
	}
	
	//NORMALIZATION
	float sum = 0;
	for (int imageX = 0; imageX < histogram.cols; imageX++){
		sum += histogram.at<float>(0, imageX);
	}
	for (int imageX = 0; imageX < histogram.cols; imageX++){
		histogram.at<float>(0, imageX) = (float)histogram.at<float>(0, imageX) / sum;
	}
	
	return histogram;
}

static Mat formatImagesForPCA(const vector<Mat> &data){

	Mat dst(static_cast<int>(data.size()), data[0].rows*data[0].cols, CV_32F);
	for (unsigned int i = 0; i < data.size(); i++){
		Mat image_row = data[i].clone().reshape(1, 1);
		Mat row_i = dst.row(i);
		image_row.convertTo(row_i, CV_32F);
	}
	return dst;
}
double applyGaussian(double Euqlidiandistance, double variance){

	double a = Euqlidiandistance * Euqlidiandistance;

	double b = 2 * variance;
	double right = exp(-a / b);

	double c = sqrt(variance) * sqrt(2 * 3.141);
	double left = (double)1 / c;

	double weight = left * right;
	return weight;
}

void createResults(map<String, vector<Mat>> AllImages){

	//FOR PART 1
	map<String, vector<Mat>> TrainingImagesAndTheirHistograms;
	vector<Mat> trainingHistograms;

	//FOR PART 1
	map<String, vector<Mat>> TestImagesAndTheirHistograms;
	vector<Mat> testHistograms;

	int numberOfTestImages = 0;
	
	//SADECE PCA YI OLUSTURMAK ICIN KULLANILDI. 
	vector<Mat> allTrainingHistograms;

	//ALL IMAGES FOR PART 2
	map<String, vector<Mat>> allImagesAndTheirHistograms;
	vector<Mat> allHistograms;

	int quantum = 8;
	//ENTER TO ALL DIRECTORIES
	map<String, vector<Mat>>::iterator outer;
	for (outer = AllImages.begin(); outer != AllImages.end(); ++outer) {
		int imageNumber = 0;
		//TRAVERSE ALL VECTORS IN TAKEN DIRECTORY
		vector<Mat>::iterator inner = outer->second.begin();
		for (inner; inner != outer->second.end(); ++inner) {
			
			if (numberOfTestImages >= outer->second.size() / 2) {
				Mat takenTestHistogram = getHistogramFourByFour(*inner, quantum);
				trainingHistograms.push_back(takenTestHistogram);
				allTrainingHistograms.push_back(takenTestHistogram);
				//PART2
				allHistograms.push_back(takenTestHistogram);
			}
			else{
				Mat takenTrainingHistogram = getHistogramFourByFour(*inner, quantum);
				testHistograms.push_back(takenTrainingHistogram);
				//PART2
				allHistograms.push_back(takenTrainingHistogram);
			}
			numberOfTestImages++;
		}
		numberOfTestImages = 0;
		TrainingImagesAndTheirHistograms[outer->first] = trainingHistograms;
		TestImagesAndTheirHistograms[outer->first] = testHistograms;

		trainingHistograms.clear();
		testHistograms.clear();
	
		//PART2
		allImagesAndTheirHistograms[outer->first] = allHistograms;
		allHistograms.clear();
	}

	// Reshape and stack images into a rowMatrix
	Mat data = formatImagesForPCA(allTrainingHistograms);

	
	// perform PCA
	double pos = 90;
	double retainedVariance = pos / 100.0;
	PCA pca(data, Mat(), CV_PCA_DATA_AS_ROW, retainedVariance);

	//PROJECT TEST IMAGES INTO PCA
	map<String, vector<Mat>> TestImagesAndTheirProjectedHistograms;
	vector<Mat> projectedTestHistograms;
	for (auto testOuter = TestImagesAndTheirHistograms.begin(); testOuter != TestImagesAndTheirHistograms.end(); ++testOuter) {
		for (auto testInner = testOuter->second.begin(); testInner != testOuter->second.end(); ++testInner) {
			Mat point = pca.project(*testInner);
			projectedTestHistograms.push_back(point);
		}
		TestImagesAndTheirProjectedHistograms[testOuter->first] = projectedTestHistograms;
		projectedTestHistograms.clear();
	}
	//PROJECT TRAINING IMAGES INTO PCA
	map<String, vector<Mat>> TrainingImagesAndTheirProjectedHistograms;
	vector<Mat> projectedTrainingHistograms;

	for (auto trainingOuter = TrainingImagesAndTheirHistograms.begin(); 
		trainingOuter != TrainingImagesAndTheirHistograms.end(); ++trainingOuter) {
		for (auto trainingInner = trainingOuter->second.begin(); trainingInner != trainingOuter->second.end(); ++trainingInner) {
			Mat point = pca.project(*trainingInner);
			projectedTrainingHistograms.push_back(point);
			
		}
		
		TrainingImagesAndTheirProjectedHistograms[trainingOuter->first] = projectedTrainingHistograms;
		projectedTrainingHistograms.clear();
	}
	//GET EACH PROJECTED TESTING HISTOGRAM.
	int success = 0;
	int failure = 0;
	for (auto testOuter = TestImagesAndTheirProjectedHistograms.begin();testOuter != TestImagesAndTheirProjectedHistograms.end(); ++testOuter) {
		//int i = 0;
		for (auto testInner = testOuter->second.begin(); testInner != testOuter->second.end(); ++testInner) {
			//i++;
			float distance = 99999999;
			String whereTestBelongs = "";
			//cout << "KLASOR ADI: " << testOuter->first << " OLAN " << i << "TH TEST IMAGE IS TAKEN" << endl;
			//GET EACH PROJECTED TRAINING HISTOGRAM.
			//int j = 0;
			for (auto trainingOuter = TrainingImagesAndTheirProjectedHistograms.begin(); trainingOuter != TrainingImagesAndTheirProjectedHistograms.end(); ++trainingOuter) {
				for (auto trainingInner = trainingOuter->second.begin(); trainingInner != trainingOuter->second.end(); ++trainingInner) {
					//j++;
					//cout << "Klasor adi " << trainingOuter->first << " olan toplamdaki " << j << "th image ile karsilastir." << endl;

					double calculatedDistance = norm(*trainingInner, *testInner, NORM_L2);

					if (calculatedDistance < distance){
						//cout << "Distance was: " << distance << " now: " << calculatedDistance << endl;
						//cout << "Klasor adi " << trainingOuter->first << " olarak degistirildi." << endl;
						distance = calculatedDistance;
						whereTestBelongs = trainingOuter->first;
					}
				}
			}
			if (whereTestBelongs.compare(testOuter->first) == 0){
				//cout << "Success for " << testOuter->first << endl;
				success += 1;
			}
			else{
				//cout << "Failure for " << testOuter->first << endl;
				failure += 1;
			}
		}
	}
	cout << endl;
	cout << "Part 1: " << endl;
	cout << "Retained variance: " << retainedVariance << endl;
	cout << "Success: " << success << endl;
	cout << "Failure: " << failure << endl;
	cout << "Success percentage is: " << ((double) success / (success + failure))* 100 << endl;
	cout << endl; 
	
	//cout << "PART 2: " << endl;


	map<String, vector<Mat>> allImagesAndTheirProjectedHistograms;
	vector<Mat> projectedHistograms;
	//PROJECT ALL IMAGES INTO PCA
	

	int numberOfRowsAfterProjection = 0;
	int numberOfColsAfterProjection = 0;
	for (auto testOuter = allImagesAndTheirHistograms.begin(); testOuter != allImagesAndTheirHistograms.end(); ++testOuter) {
		int i = 0; 
		for (auto testInner = testOuter->second.begin(); testInner != testOuter->second.end(); ++testInner) {
			//cout << "Before projection: " << (*testInner).size() << endl;
			Mat point = pca.project(*testInner);
			numberOfColsAfterProjection = point.cols;
			numberOfRowsAfterProjection = point.rows;
			//cout << "After projection: " << point.size() << endl;
			projectedHistograms.push_back(point);
			i++;
		}
		//cout << "There are " << i << "images in the " << testOuter->first << endl;
		allImagesAndTheirProjectedHistograms[testOuter->first] = projectedHistograms;
		projectedHistograms.clear();
	}

	double variance = 0.95;
	double bandwith = variance; 

	double sum = 0;
	int numberOfPoints = 0;
	
	Mat M = Mat::zeros(1, numberOfColsAfterProjection, CV_32FC1);
	
	cout << endl;
	cout << "PART2" << endl;
	//WEIGHTS OFF ALL IMAGES
	int numberOfClusters = 0;
	double threshold = 0.5;
	for (auto outer = allImagesAndTheirProjectedHistograms.begin(); outer != allImagesAndTheirProjectedHistograms.end(); ++outer) {
		for (auto inner = outer->second.begin(); inner != outer->second.end(); ++inner) {
			
			double mean = 0;
			double weight = 0;
			Mat point = *inner;
			double allWeights = 0;
			for (auto testOuter = allImagesAndTheirProjectedHistograms.begin(); testOuter != allImagesAndTheirProjectedHistograms.end(); ++testOuter) {
				for (auto testInner = testOuter->second.begin(); testInner != testOuter->second.end(); ++testInner) {

						//TRAVEL ALL OTHER POINTS
						Mat otherPoint = *testInner;
						
						//FIND THE EUQLIDIAN DISTANCE BETWEEN THEM
						double Euqlidiandistance = norm(point, otherPoint, NORM_L2);
						
						//GIVEN SIGMA AND EUQLIDIAN DISTANCE, APPLY GAUSSIAN
						weight = applyGaussian(Euqlidiandistance, variance);
						
						for (int i = 0; i < otherPoint.cols; i++){
							mean += weight * otherPoint.at<float>(0, i);
						}
						allWeights += weight;
				}
			}

			//THIS IS NEW CENTER OR CALL THIS AS A WEIGHTED AVERAGE
			double weightedaverage = (double) mean / allWeights;
			
			//HOW MUCH CENTER SHIFTED
			double howMuchItShifts = 0;
			for (int i = 0; i < point.cols; i++){
				howMuchItShifts += point.at<float>(0, i) - weightedaverage;
			}
			if (threshold < howMuchItShifts){
				numberOfClusters++;
			}
		}
	}
	cout << "The number of clusters is: " << numberOfClusters;
	cout << endl;
}

int main() {

	//TAKE DIRECTORY NAMES
	vector<string> namesOfDirectories;

	DIR *dir;
	struct dirent *ent;

	if ((dir = opendir("DATASET")) != NULL) {
		while ((ent = readdir(dir)) != NULL) {
			if (string(ent->d_name) == "." || string(ent->d_name) == ".."){

			}
			else{
				namesOfDirectories.push_back(string(ent->d_name));
			}
		}
		closedir(dir);
	}
	else {
		perror("");
		return EXIT_FAILURE;
	}

	//TAKE ALL IMAGES IN TAKEN DIRECTORIES
	map<String, vector<Mat>> AllImages;

	for (int i = 0; i < namesOfDirectories.size(); i++){
		string dirName = "DATASET//"
			+ namesOfDirectories.at(i);

		DIR *dir;
		dir = opendir(dirName.c_str());

		string imgName;
		if (dir != NULL) {
			vector <Mat> allMatsInOneDirectory;
			while ((ent = readdir(dir)) != NULL) {

				imgName = string(ent->d_name);

				if (imgName == "." || imgName == ".."){

				}
				else{
					Mat img = imread(dirName + "//" + imgName, 1);
					allMatsInOneDirectory.push_back(img);
					if (!img.data){
						cout << "Could not open or find the image" << std::endl;
						return -1;
					}
				}
			}
			AllImages[namesOfDirectories[i]] = allMatsInOneDirectory;
			closedir(dir);
		}
		else {
			cout << "not present" << endl;
		}
	}

	createResults(AllImages);

	return 0;
}